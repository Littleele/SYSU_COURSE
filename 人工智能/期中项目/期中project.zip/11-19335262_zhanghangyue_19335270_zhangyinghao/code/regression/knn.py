# coding=utf-8
import random
import re
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import PCA
from gensim.models import doc2vec
from sklearn.model_selection import train_test_split
import csv
import matplotlib.pyplot as plt


# flag=0读取训练集+验证集,flag=1读取测试集(无label)
def word_split(filename, flag):
    text = []
    label = []
    filtered_text = []
    pre_data = pd.read_csv(filename)
    df = pd.DataFrame(pre_data)
    id = df.iloc[:, 0:1].values
    # 脏数据清洗，填充默认值
    with open(filename, 'r', encoding='utf-8') as f:
        next(f)
        reader = csv.reader(f)
        if flag == 0:
            for row in reader:
                if row[2] == '0':  # 跳过取零的行
                    continue
                temp = re.sub('[^a-zA-Z]+', ' ', row[1])  # 只保留英文单词
                temp = temp.lower()  # 全部转换为小写
                text.append(temp)
                label.append(float(row[3]))
        if flag == 1:
            for row in reader:
                temp = re.sub('[^a-zA-Z]+', ' ', row[1])  # 只保留英文单词
                temp = temp.lower()  # 全部转换为小写
                text.append(temp)

    stop_words = set(stopwords.words('english'))
    for row in text:
        word_list1 = word_tokenize(row)
        word_list2 = [word for word in word_list1 if word not in stop_words]
        word_list3 = []
        for word in word_list2:
            word_list3.append(PorterStemmer().stem(word))
        word_list4 = []
        for word in word_list3:
            word_list4.append(WordNetLemmatizer().lemmatize(word, pos='v'))
        temp = " ".join(word_list4)  # 合并为一个列表 便于后续计算tf-idf矩阵
        filtered_text.append(temp)
    return filtered_text, np.array(label), id


def split_data(dataset, label):
    total = len(dataset)
    step = total // 10
    train_set = dataset[:step * 7]
    train_label = label[:step * 7]
    valid_set = dataset[step * 7:]
    valid_label = label[step * 7:]

    return train_set, valid_set, train_label, valid_label


def tf_idf(word):
    """
    得到tfidf矩阵
    """
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(word)
    transformer = TfidfTransformer()
    tfidf = transformer.fit_transform(X)
    return tfidf.toarray()


def build_doc2vec(data, size, name):
    # PV-DM
    x_train = []
    TaggededDocument = doc2vec.TaggedDocument
    # 改编成doc2vec所需输入格式
    for i, text in enumerate(data):
        word_list = text.split(' ')
        l = len(word_list)
        word_list[l - 1] = word_list[l - 1].strip()
        document = TaggededDocument(word_list, tags=[i])
        x_train.append(document)
    # 加载doc2vec模型
    model = doc2vec.Doc2Vec(x_train, min_count=1, window=3, vector_size=size,
                            sample=1e-4, negative=5, workers=4)
    # 开始训练
    model.train(x_train, total_examples=model.corpus_count, epochs=10)
    model.save(name)
    return model.dv.vectors  # 返回文档向量


def pca_byhand(data, k):
    avg = np.mean(data, 0)
    m, n = np.shape(data)
    data_adjust = data - avg
    covdata = np.dot(data_adjust.T, data_adjust)  # 求解协方差矩阵
    featvalue, featvec = np.linalg.eig(covdata)  # 求解特征值
    index = np.argsort(featvalue)[-k:]  # 选取从大到小的下标
    w = featvec[:, index]  # 选取最大的k个特征值对应的特征向量
    reduced = np.dot(data_adjust, w)
    return reduced


def pca(tfidf, dim):
    tfidf_reduced = PCA(n_components=dim).fit_transform(tfidf)
    return tfidf_reduced


def cal(row, train_met, n):
    row = row.reshape(1, -1)
    temp = np.repeat(row, train_met.shape[0], axis=0)

    # 欧氏距离
    if n == 2:
        temp1 = np.square(temp - train_met)
        sum_list = np.sum(temp1, axis=1)
        sum_list = np.sqrt(sum_list)
    # 曼哈顿距离
    elif n == 1:
        temp1 = np.abs(temp - train_met)
        sum_list = np.sum(temp1, axis=1)
    # 余弦距离
    elif n == 3:
        num = np.inner(row, train_met)
        denom = np.linalg.norm(temp, axis=1) * np.linalg.norm(train_met, axis=1)
        # 排除分母为0的情况 但是d2v降维不会存在向量全0的情况
        # for row in denom:
        #     if row==0:
        #         row=0.001
        cos = num / denom
        return 1 - cos  # cos越大相关性越高，但因为排序 选前k个最小的数，所以return 1-cos

    return sum_list.reshape(1, -1)


def knn_predict_avg(valid_met, train_met, train_label, k, function):
    predict = []
    for i in range(len(valid_met)):
        row = valid_met[i]
        sum_list = cal(row, train_met, n=function)
        sum_index = np.argsort(sum_list)
        total = 0
        for j in range(k):
            total += train_label[sum_index[0][j]]
        total /= k
        predict.append(total)
    return predict


def knn_predict_weight(valid_met, train_met, train_label, k, function):
    predict = []
    for i in range(len(valid_met)):
        row = valid_met[i]
        dis_list = cal(row, train_met, n=function)
        dis_index = np.argsort(dis_list)
        k_index = dis_index[0][0:k]
        # 计算所有邻居节点的距离倒数 之和 以防出现分母为0的情况
        sum = np.sum(1 / (dis_list[0][k_index] + 0.01))
        weight = (1 / (dis_list[0][k_index]) + 0.01) / sum
        label = train_label[k_index]
        output = np.inner(weight, label)
        predict.append(output)

    return predict


def cal_acc(predict, label, threshold):
    diff = predict - label
    loss = np.square(np.mean((diff) ** 2))
    cnt = 0
    for i in range(diff.shape[0]):
        if diff[i] < threshold:
            cnt += 1
    acc = cnt / diff.shape[0]
    return loss, acc


def knn_test(train_reduced, train_label, output_file, k, n):
    filtered_text, label_temp, id = word_split('test_regression.csv', 1)
    # test_tfidf = tf_idf(filtered_text)
    # test_reduced = pca(test_tfidf, 25)
    test_reduced = build_doc2vec(filtered_text, 35, 'test.d2v')
    # d2v调用模型训练
    test_model = doc2vec.Doc2Vec.load('test.d2v')
    test_reduced = test_model.dv.vectors
    output = knn_predict_avg(test_reduced, train_reduced, train_label, k, n)
    id = list(id.flat)
    test_output = pd.DataFrame({'id': id, 'humor_rating': output})
    test_output.to_csv(output_file, encoding='utf8', index=None)


if __name__ == "__main__":
    text, label, id = word_split('train_r.csv', 0)
    threshold = 0.2

    train_text, valid_text, train_label, valid_label = split_data(text, label)
    # # pca降维
    train_tfidf = tf_idf(train_text)
    valid_tfidf = tf_idf(valid_text)
    train_reduced = pca(train_tfidf, 30)
    valid_reduced = pca(valid_tfidf, 30)

    # # doc2voc初次训练降维
    # train_reduced = build_doc2vec(train_text, 35, "train.d2v")
    # valid_reduced = build_doc2vec(valid_text, 35, "valid.d2v")
    #
    # # doc2vec调用模型降维
    # train_model = doc2vec.Doc2Vec.load('train.d2v')
    # valid_model = doc2vec.Doc2Vec.load('valid.d2v')
    # train_reduced = train_model.dv.vectors
    # valid_reduced = valid_model.dv.vectors

    # knn做法

    # for k in range(2, 100):
    #     out = knn_predict_weight(valid_reduced, train_reduced, train_label, k, 2)
    #     loss, acc = cal_acc(out, valid_label, threshold)
    #     print("第%s迭代时，loss=%s,acc=%s" % (k, loss, acc))

    # plt.plot(x, y1, label='n=1')
    # plt.plot(x, y2, label='n=2')
    # plt.plot(x, y3, label='n=3')
    # plt.legend()
    # plt.xlabel('k')
    # plt.ylabel('Loss')
    # plt.title('Loss when knn_weight')
    # plt.show()

    # knn测试集
    knn_test(train_reduced, train_label, 'outputk7.csv', 100,2)
