# Readme

1. classification中存放分类任务代码。

+ bayis.py 贝叶斯分类方法实现
+ knn knn分类方法实现
+ mean_square_nn是神经网络平方损失函数
+ cross_nn是神经网络交叉熵损失函数

+ 最优结果获得

  将文件train.csv​和文件​test\_classification.csv​与代码文件放在同一目录下，所有代码直接运行可以得到验证集准确率（参数已调为各模型最佳实现）

  Private分类最佳结果由贝叶斯算法实现，将bayis.py$中第198-199行注释，去掉第202-205行注释，直接运行即可得到测试集结果



2. regression中存放回归任务代码。

+ knn.py knn回归方法实现 其中包含knn平均和knn权重两个方法

+ bpnn.py 神经网络方法实现 其中包含BGD和MBGD两种方法

+ 最优结果获得

  Private分类最佳结果由knn算法实现，利用PCA将原数据降维至30维，采用knn平均计算法，欧氏距离，k=100。直接运行程序即可得到测试集结果。



