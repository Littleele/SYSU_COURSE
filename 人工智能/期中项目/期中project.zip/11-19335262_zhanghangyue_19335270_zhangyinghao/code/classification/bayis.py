# coding=utf-8
import re
import math
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer


# flag=0读取训练集+验证集,flag=1读取测试集(无label)
def word_split(filename, flag):
    text = []
    label = []
    filtered_text = []
    # 脏数据清洗，填充默认值
    pre_data = pd.read_csv(filename)
    # pre_data.humor_rating.fillna(0)
    df = pd.DataFrame(pre_data)
    id = df.iloc[:, 0:1].values
    data = df.iloc[:, 1:2].values.tolist()
    if flag == 0:
        label = df.iloc[:, 2:3].values.tolist()
    # 正则表达式过滤字符
    for row in data:
        temp = re.sub('[^a-zA-Z0-9 !?]', '', row[0])  # 只保留英文单词
        temp = temp.lower()  # 全部转换为小写
        text.append(temp)

    stop_words = set(stopwords.words('english'))
    for row in text:
        # 分词
        word_list1 = word_tokenize(row)
        # 过滤停用词
        word_list2 = [word for word in word_list1 if word not in stop_words]
        # 提取词干
        word_list3 = []
        for word in word_list2:
            word_list3.append(PorterStemmer().stem(word))
        # 词性还原
        word_list4 = []
        for word in word_list3:
            word_list4.append(WordNetLemmatizer().lemmatize(word, pos='v'))
        # temp = " ".join(word_list4)  # 合并为一个字符串列表
        filtered_text.append(word_list4)
    return filtered_text, np.array(label), id


def split_data(dataset, label):
    total = len(dataset)
    step = total // 10
    train_set = dataset[:step * 8]
    train_label = label[:step * 8]
    valid_set = dataset[step * 8:]
    valid_label = label[step * 8:]

    return train_set, valid_set, train_label, valid_label


def count_word(train, test):
    """
    :param train:train单词列表
    :param test:test单词列表
    :return:返回无重复单词的列表
    """
    wordset = set()  # 利用set加快查找速度
    wordlist = []
    for row in train:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    for row in test:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    return wordlist


def get_sub_dataset(dataset, labelset, label):
    """
    :param dataset:
    :param labelset: 属性集合
    :param label: 希望得到的子集标签值
    :return:
    """
    record = []
    for i in range(len(labelset)):
        if labelset[i] == label:
            record.append(dataset[i])  # 因为labelset和dataset元素是一一对应的
    return record


def cal_prob(subdataset, index):
    # index为该单词在wordlist中的下标
    total = len(subdataset)
    count1 = 0
    for line in subdataset:
        if line[index] != 0:
            count1 += line[index]
    if count1 == 0:
        # 处理测试集单词不存在于训练集的情况，返回一个相对较小的负数
        return 0.15 / total
    else:
        # return 1 + count1 / total
        return count1 / total


def cal_label(labelset):
    count1 = 0
    for i in labelset:
        if i == 1:
            count1 += 1

    pro1 = count1 / len(labelset)
    return pro1, 1 - pro1


def tf_idf(data, word_table):
    """
    得到tfidf矩阵
    """
    # TF:
    ans = []
    for sem in data:
        temp = []
        size = len(sem)
        print(len(ans))
        for word in word_table:
            if size == 0:
                temp.append(0)
            else:
                temp.append(sem.count(word) / size)
        ans.append(temp)
    # IDF:
    IDF = []
    for word in word_table:
        print(len(IDF))
        sum = 0
        for sem in data:
            if word in sem:
                sum += 1
        IDF.append(np.log(len(data) / (sum + 1)))
    # TDIDF:
    for i in range(len(word_table)):
        for j in range(len(data)):
            ans[j][i] = ans[j][i] * IDF[i]
    return ans


def Bayes_class(train_set, valid_set, train_label, valid_label, flag):
    predict_label = []
    sub1 = get_sub_dataset(train_set, train_label, 1)  # 所有label为1的数据
    sub0 = get_sub_dataset(train_set, train_label, 0)  # 所有label为0的数据
    pro1, pro0 = cal_label(train_label)  # 计算类别概率
    for i, line in enumerate(valid_set):
        one_pro = 1
        zero_pro = 1
        for index, element in enumerate(line):
            if element != 0:
                one_pro += math.log(cal_prob(sub1, index))
                zero_pro += math.log(cal_prob(sub0, index))
        print("one_pro = ", one_pro, ", label_one = ", math.log(pro1 + 1))
        print("zero_pro = ", zero_pro, ", label_zero = ", math.log(pro0 + 1))
        out1 = one_pro + math.log(pro1 + 1)
        out0 = zero_pro + math.log(pro0 + 1)
        if (out1 > out0):
            predict_label.append(1)
        else:
            predict_label.append(0)
        print("i=", i, " pre_label=", predict_label[len(predict_label) - 1])
    if flag == 0:
        cal_acc(predict_label, valid_label)
        return []
    elif flag == 1:
        return predict_label


def cal_acc(predict, valid_label):
    total = len(predict)
    count = 0
    for i in range(len(predict)):
        if predict[i] == valid_label[i]:
            count += 1
    print(count / total)


if __name__ == "__main__":
    text, label, id = word_split('train.csv', 0)
    test_text, test_label, test_id = word_split('test_classification.csv', 1)
    word_table = count_word(text, test_text)
    data_tfidf = tf_idf(text, word_table)
    test_tfidf = tf_idf(test_text, word_table)

    # 划分训练验证集
    train_text, valid_text, train_label, valid_label = split_data(data_tfidf, label)
    Bayes_class(train_text, valid_text, train_label, valid_label, 0)

    # 测试集
    # test_id = list(test_id.flat)
    # out = Bayes_class(data_tfidf, test_tfidf, label, label, 1)
    # test_output = pd.DataFrame({'id': test_id, 'is_humor': out})
    # test_output.to_csv("my_text.csv", encoding='utf8', index=None)
