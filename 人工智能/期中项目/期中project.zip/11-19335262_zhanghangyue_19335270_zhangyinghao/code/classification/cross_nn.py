# coding=utf-8
import random
import math
import re
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import PCA
from gensim.models import doc2vec


# flag=0读取训练集+验证集,flag=1读取测试集(无label)
def word_split(filename, flag):
    text = []
    label = []
    filtered_text = []
    # 脏数据清洗，填充默认值
    pre_data = pd.read_csv(filename)
    # pre_data.humor_rating.fillna(0)
    df = pd.DataFrame(pre_data)
    id = df.iloc[:, 0:1].values
    data = df.iloc[:, 1:2].values.tolist()
    if flag == 0:
        label = df.iloc[:, 2:3].values.tolist()
    # 正则表达式过滤字符
    for row in data:
        temp = re.sub('[^a-zA-Z0-9 !?]', '', row[0])  # 只保留英文单词
        temp = temp.lower()  # 全部转换为小写
        text.append(temp)

    stop_words = set(stopwords.words('english'))
    for row in text:
        # 分词
        word_list1 = word_tokenize(row)
        # 过滤停用词
        word_list2 = [word for word in word_list1 if word not in stop_words]
        # 提取词干
        word_list3 = []
        for word in word_list2:
            word_list3.append(PorterStemmer().stem(word))
        # 词性还原
        word_list4 = []
        for word in word_list3:
            word_list4.append(WordNetLemmatizer().lemmatize(word, pos='v'))
        # filtered_text.append(word_list4)
        temp = " ".join(word_list4)  # 合并为一个列表
        filtered_text.append(temp)
    return filtered_text, np.array(label), id


def split_data(dataset, label):
    total = len(dataset)
    step = total // 10
    train_set = dataset[:step * 7]
    train_label = label[:step * 7]
    valid_set = dataset[step * 7:]
    valid_label = label[step * 7:]

    return train_set, valid_set, train_label, valid_label


def count_word(train, test):
    """
    :param train:train单词列表
    :param test:test单词列表
    :return:返回无重复单词的列表
    """
    wordset = set()  # 利用set加快查找速度
    wordlist = []
    for row in train:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    for row in test:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    return wordlist


def tf_idf(word):
    """
    得到tfidf矩阵
    """
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(word)
    transformer = TfidfTransformer()
    tfidf = transformer.fit_transform(X)
    return tfidf.toarray()


def build_doc2vec(data, size, name):
    # PV-DM
    x_train = []
    TaggededDocument = doc2vec.TaggedDocument
    # 改编成doc2vec所需输入格式
    for i, text in enumerate(data):
        word_list = text.split(' ')
        l = len(word_list)
        word_list[l - 1] = word_list[l - 1].strip()
        document = TaggededDocument(word_list, tags=[i])
        x_train.append(document)
    # 加载doc2vec模型
    model = doc2vec.Doc2Vec(x_train, min_count=1, window=3, vector_size=size, sample=1e-3, negative=5, workers=4)
    model.train(x_train, total_examples=model.corpus_count, epochs=10)
    # 开始训练
    model.save(name)
    return model.dv.vectors  # 返回文档向量


def pca(tfidf, dim):
    tfidf_reduced = PCA(n_components=dim).fit_transform(tfidf)
    return tfidf_reduced


def predict(w, b, valid_set, label):
    """
    将训练得到的w和b带入验证集 检测正确率
    """
    total = len(valid_set)
    cnt = 0
    for i in range(total):
        temp = np.dot(valid_set[i], w) + b
        if label[i] == np.sign(temp) or temp == 0:  # 要注意当temp=0时也认为是预测正确
            cnt += 1
    return cnt / total


def make_matrix(row_num, col_num):
    """
    生成矩阵，大小为row_num*col_num， 数值随机
    :param row_num: 行数
    :param col_num: 列数
    :return: 返回矩阵list
    """
    result = []
    for i in range(row_num):
        temp = []
        for j in range(col_num):
            temp.append(random.uniform(-1.0, 1.0))  # 产生一个随机数在（-1,1）之间
        result.append(temp)
    return result


def init_para(dataset, hnode_num):
    """
    初始化各参数
    :param dataset:
    :param hnode_num:
    :return: w_hidden, b_hidden, w_output, b_output
    """
    feature_num = dataset.shape[1]  # 第一维等于变量数
    w_hidden = np.array(make_matrix(feature_num, hnode_num))
    b_hidden = np.array(make_matrix(1, hnode_num))
    w_output = np.array(make_matrix(hnode_num, 1))
    b_output = random.uniform(0, 1.0)  # b_output初始化为[-1,1]之间的一个数
    return w_hidden, b_hidden, w_output, b_output


def sigmoid(x):
    ans = []
    for i in range(len(x)):
        temp = []
        for j in range(len(x[0])):
            if x[i][j] >= 0:
                temp.append(1.0 / (1 + np.exp(-1 * x[i][j])))
            else:
                temp.append(np.exp(x[i][j]) / (1 + np.exp(x[i][j])))
        ans.append(temp)
    return np.array(ans)


def activation_func(func_type, x):
    if func_type == "sigmoid":
        # 跑测试集的时候要加这句话！
        x = np.array(x, dtype=np.float64)  # 否则会出错
        return sigmoid(x)
    elif func_type == "tanh":
        return 2 * sigmoid(2 * x) - 1
        # return (np.exp(x) - np.exp(-x)) / (np.exp(x) + np.exp(-x))
    elif func_type == "relu":
        return np.maximum(0.01 * x, x)


def derivation(func_type, hidden_output):  # 激活函数的求导
    if func_type == "sigmoid":
        return hidden_output * (1 - hidden_output)
    elif func_type == "tanh":
        return 1 - np.square(hidden_output)
    elif func_type == "relu":
        temp = [[0.0] * len(hidden_output[0]) for i in range(len(hidden_output))]  # 二维数组初始化
        for i, data in enumerate(hidden_output):
            for j, data_each in enumerate(data):
                if data_each < 0:
                    temp[i][j] = 0.01
                else:
                    temp[i][j] = 1
        result = np.array(temp)
        return result


def forward_pass(dataset, w_hidden, b_hidden, w_output, b_output, func_type):
    """
    前向传播
    :param dataset: 数据集
    :param w_hidden : 隐藏层 w
    :param b_hidden: 隐藏层b（偏置theta)
    :param w_output: 输出层 w
    :param b_output: 输出层 b
    :param func_type: 激活函数类型
    :return: output, hidden_output
    """
    data_num = dataset.shape[0]  # 样本数
    # 隐藏层计算
    b_hidden1 = np.repeat(b_hidden, data_num, axis=0)  # 将b_hidden沿着行扩展
    hidden_input = np.dot(dataset, w_hidden)  # 隐藏层节点
    hidden_input = hidden_input + b_hidden1  # 加上偏置theta
    hidden_output = activation_func(func_type, hidden_input)  # 激活函数
    # 输出层计算
    output = np.dot(hidden_output, w_output)  # 输出层预测输出
    b_output1 = np.array([b_output] * data_num)  # 这样可以形成数组，且各单元值相同。因为这只是一个数，所以用按行repeat不会形成列向量；多个数就会
    b_output1 = b_output1.reshape(-1, 1)  # 转成列向量
    out_input = output + b_output1  # 加上偏置量
    out_output = activation_func(func_type, out_input)
    return out_output, hidden_output


# 交叉熵的反向传播
def backward_pass(dataset, label, out_output, hidden_output, learning_rate, w_hidden, b_hidden, w_output, b_output,
                  func_type):
    feature_num = dataset.shape[1]
    hnode_num = hidden_output.shape[1]  # 隐藏层节点数,等于feature_num
    data_num = dataset.shape[0]  # 样本数
    label = label.reshape(-1, 1)
    # 用梯度来表示
    # 更新输出层
    # omega_out_grad = (out_output - label).repeat(feature_num, axis=1) * hidden_output
    # omega_out_grad = np.mean(omega_out_grad, axis=0)
    # b_out_grad = out_output - label
    # b_out_grad = np.mean(b_out_grad, axis=0)
    # w_output -= learning_rate * omega_out_grad.reshape(-1, 1)
    # b_output -= learning_rate * b_out_grad[0]
    # # 更新隐藏层
    # omega_hidden_grad = []
    # for i in range(hnode_num):
    #     w_output1 = w_output.reshape(1, feature_num)
    #     temp = (out_output - label) * w_output1 * derivation(func_type, hidden_output) * \
    #            dataset[:, i].reshape(-1, 1).repeat(feature_num, axis=1)
    #     temp = np.mean(temp, axis=0)
    #     omega_hidden_grad.append(temp.tolist())
    # omega_hidden_grad = np.array(omega_hidden_grad)
    # b_hidden_grad = []
    # sum_out_w = 0
    # for i in range(w_output.shape[0]):
    #     sum_out_w += w_output[i][0]
    # for i in range(hnode_num):
    #     temp = (out_output - label) * sum_out_w * derivation(func_type, hidden_output[:, i]).reshape(-1, 1)
    #     temp = np.mean(temp, axis=0)
    #     b_hidden_grad.append(temp[0])
    # b_hidden_grad = np.array(b_hidden_grad)
    # w_hidden -= learning_rate * omega_hidden_grad
    # b_hidden -= learning_rate * b_hidden_grad.reshape(-1, 1).reshape(1, feature_num)

    # 逐层误差做法
    err_output = out_output-label
    # 求出所有样本的平均误差：输出层平均
    err_output1 = np.repeat(err_output, hnode_num, axis=1)
    err_output1 = err_output1 * hidden_output   # 先乘法
    err_output_mean_w = np.mean(err_output1, axis=0)    # 更新w时的误差*Oj的均值
    err_output_mean_b = np.mean(err_output)     # 更新b时的误差均值
    # 更新输出层的w,b：
    for i in range(hnode_num):
        w_output[i] -= learning_rate * err_output_mean_w[i]
    b_output -= learning_rate * err_output_mean_b
    # 计算err_output * w_output
    temp = np.repeat(err_output, hnode_num, axis=1)  # 沿着列扩展err_k
    temp_w_output = np.repeat(w_output.reshape(1, hnode_num), data_num, axis=0)   # 沿着行扩展w_output，原来是（hnode_num,1）
    temp = temp * temp_w_output

    # 计算隐藏层误差 err_hidden
    err_hidden = derivation(func_type, hidden_output) * temp
    # 求出所有样本的平均误差：隐藏层平均
    #err_hidden_mean_b = np.mean(err_hidden, axis=0) #ques
    err_hidden_b2 = []
    for i in range(dataset.shape[0]):
        err_hidden_b1 = []
        for j in range(feature_num):
            err_hidden_b1.append(err_output[i][0]*w_output[j][0]*derivation(func_type,hidden_output[i][j]))
        err_hidden_b2.append(err_hidden_b1)
    err_hidden_b3 = np.array(err_hidden_b2)
    err_hidden_mean_b = np.mean(err_hidden_b3, axis=0)
    err_hidden_mean_w = []
    for i in range(hnode_num):
        x_i = dataset[:,i]
        x_i = np.repeat(x_i.reshape(-1,1),feature_num, axis=1)
        err_hidden_each = err_hidden * x_i
        err_hidden_each1 = np.mean(err_hidden_each, axis=0)
        err_hidden_mean_w.append(err_hidden_each1.tolist())
    err_hidden_mean_w = np.array(err_hidden_mean_w)
    # 更新隐藏层的w,b：
    for j in range(feature_num):
        for i in range(hnode_num):
            w_hidden[i][j] -= learning_rate * err_hidden_mean_w[i][j]
        b_hidden[0][j] -= learning_rate * err_hidden_mean_b[j]     # b_hidden是一个行向量，(1,hnode_num)

    return w_hidden, b_hidden, w_output, b_output


def bpnn(hnode_num, dataset, label, iteration, learning_rate, func_type):
    w_hidden, b_hidden, w_output, b_output = init_para(dataset, hnode_num)
    cur_eta = learning_rate
    pre_ent = 100000
    for i in range(iteration):
        # 前向传播：得到输出层和隐藏层的输出
        out_output, hidden_output = forward_pass(dataset, w_hidden, b_hidden, w_output, b_output, func_type)
        # 后向传播：更新两组w,b
        w_hidden, b_hidden, w_output, b_output = backward_pass(dataset, label, out_output, hidden_output, cur_eta,
                                                               w_hidden, b_hidden, w_output, b_output, func_type)
        loss, accuracy, cur_eta, pre_ent = validation(valid_reduced, valid_label, func_type, w_hidden, b_hidden,
                                                      w_output, b_output, cur_eta, pre_ent)
        print("在迭代次数为%s时，loss is %s, accuracy is %s" % (i + 1, loss, accuracy))
    return w_hidden, b_hidden, w_output, b_output


def validation(dataset, label, func_type, w_hidden, b_hidden, w_output, b_output, cur_eta, pre_ent):  # 预测验证集的输出
    out_output, hidden_output = forward_pass(dataset, w_hidden, b_hidden, w_output, b_output, func_type)
    cur_ent = np.sum((out_output - label).sum(axis=0))
    if abs(cur_ent) > abs(pre_ent):
        cur_eta /= 10
        print("学习率为： ", cur_eta)
    pre_ent = cur_ent
    diff = out_output - label
    loss = np.mean(np.square(diff)) / 2
    cnt = 0
    for i in range(out_output.shape[0]):
        if (out_output[i] > 0.5):
            temp = 1
        else:
            temp = 0
        if label[i] == temp:
            cnt += 1
    accuracy = cnt / diff.shape[0]
    return loss, accuracy, cur_eta, pre_ent


if __name__ == "__main__":
    func_type = "sigmoid"
    learning_rate = 0.05
    hnode_num = 50
    iteration = 20
    text, label, id_temp = word_split('train.csv', 0)

    # pca进行降维
    # data_tfidf = tf_idf(text)
    # train_tfidf, valid_tfidf, train_label, valid_label = split_data(data_tfidf, label)
    # train_reduced = pca(train_tfidf, hnode_num)
    # valid_reduced = pca(valid_tfidf, hnode_num)

    # doc2vec初次降维
    train_text, valid_text, train_label, valid_label = split_data(text, label)
    train_reduced = build_doc2vec(train_text, hnode_num, "my_train1.d2v")
    valid_reduced = build_doc2vec(valid_text, hnode_num, "my_valid1.d2v")

    # doc2vec使用训练好的模型
    # temp1, temp2, train_label, valid_label = split_data(text, label)
    # train_model = doc2vec.Doc2Vec.load('train.d2v')
    # valid_model = doc2vec.Doc2Vec.load('valid.d2v')
    # train_reduced = train_model.dv.vectors
    # valid_reduced = valid_model.dv.vectors

    w_hidden, b_hidden, w_output, b_output = bpnn(hnode_num, train_reduced, train_label,
                                                  iteration, learning_rate, func_type)
