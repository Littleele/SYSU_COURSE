# coding=utf-8
import random
import math
import re
import numpy as np
import pandas as pd
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
from sklearn.decomposition import PCA
from gensim.models import doc2vec


# flag=0读取训练集+验证集,flag=1读取测试集(无label)
def word_split(filename, flag):
    text = []
    label = []
    filtered_text = []
    # 脏数据清洗，填充默认值
    pre_data = pd.read_csv(filename)
    # pre_data.humor_rating.fillna(0)
    df = pd.DataFrame(pre_data)
    id = df.iloc[:, 0:1].values
    data = df.iloc[:, 1:2].values.tolist()
    if flag == 0:
        label = df.iloc[:, 2:3].values.tolist()
    # 正则表达式过滤字符
    for row in data:
        temp = re.sub('[^a-zA-Z0-9 !?]', '', row[0])  # 只保留英文单词
        temp = temp.lower()  # 全部转换为小写
        text.append(temp)

    stop_words = set(stopwords.words('english'))
    for row in text:
        # 分词
        word_list1 = word_tokenize(row)
        # 过滤停用词
        word_list2 = [word for word in word_list1 if word not in stop_words]
        # 提取词干
        word_list3 = []
        for word in word_list2:
            word_list3.append(PorterStemmer().stem(word))
        # 词性还原
        word_list4 = []
        for word in word_list3:
            word_list4.append(WordNetLemmatizer().lemmatize(word, pos='v'))
        temp = " ".join(word_list4)  # 合并为一个列表
        filtered_text.append(temp)
    return filtered_text, np.array(label), id


def split_data(dataset, label):
    total = len(dataset)
    step = total // 10
    train_set = dataset[:step * 7]
    train_label = label[:step * 7]
    valid_set = dataset[step * 7:]
    valid_label = label[step * 7:]

    return train_set, valid_set, train_label, valid_label


def count_word(train, test):
    """
    :param train:train单词列表
    :param test:test单词列表
    :return:返回无重复单词的列表
    """
    wordset = set()  # 利用set加快查找速度
    wordlist = []
    for row in train:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    for row in test:
        for i in row:
            if i not in wordset:
                wordset.add(i)
                wordlist.append(i)
    return wordlist


def tf_idf(word):
    """
    得到tfidf矩阵
    """
    vectorizer = CountVectorizer()
    X = vectorizer.fit_transform(word)
    transformer = TfidfTransformer()
    tfidf = transformer.fit_transform(X)
    return tfidf.toarray()


def find_kth_mini(dis, index, st, end, k):  # 前k个最小值
    i = st
    j = end
    pivot = dis[i]
    pivot_index = index[i]
    while i < j:
        while i < j and dis[j] > pivot:
            j -= 1
        if i < j:
            dis[i] = dis[j]
            index[i] = index[j]
            i += 1
        while i < j and dis[i] <= pivot:
            i += 1
        if i < j:
            dis[j] = dis[i]
            index[j] = index[i]
            j -= 1
    dis[j] = pivot
    index[j] = pivot_index
    if j == k - 1:
        return index[0:k]
    elif j > k - 1:
        return find_kth_mini(dis, index, st, j - 1, k)
    else:
        return find_kth_mini(dis, index, j + 1, end, k)


def count_label(kth, train_label):  # 统计众数得到结果label
    my_label = []
    for index in kth:
        my_label.append(train_label[index])
    return max(my_label, key=my_label.count)


def build_doc2vec(data, size, name):
    # PV-DM
    x_train = []
    TaggededDocument = doc2vec.TaggedDocument
    # 改编成doc2vec所需输入格式
    for i, text in enumerate(data):
        word_list = text.split(' ')
        l = len(word_list)
        word_list[l - 1] = word_list[l - 1].strip()
        document = TaggededDocument(word_list, tags=[i])
        x_train.append(document)
    # 加载doc2vec模型
    model = doc2vec.Doc2Vec(x_train, min_count=1, window=3, vector_size=size, sample=1e-3, negative=5, workers=4)
    model.train(x_train, total_examples=model.corpus_count, epochs=10)
    # 开始训练
    model.save(name)
    return model.dv.vectors  # 返回文档向量


def pca(tfidf, dim):
    tfidf_reduced = PCA(n_components=dim).fit_transform(tfidf)
    return tfidf_reduced


def knn(k, p, train_data, train_label, valid_data, valid_label):  # 进行knn训练,返回准确率
    # 缺点是速度慢 + 效率不高
    accuracy = 0
    for valid_index in range(valid_data.shape[0]):
        print("No ",valid_index)
        dis = []
        for train_index in range(train_data.shape[0]):
            vec1 = valid_data[valid_index, :]
            vec2 = train_data[train_index, :]
            distance = np.linalg.norm(vec1 - vec2, ord=p)
            dis.append(distance)
        my_index = []
        for index in range(len(dis)):
            my_index.append(index)
        kth = find_kth_mini(dis, my_index, 0, len(dis) - 1, k)
        final_label = count_label(kth, train_label)
        if final_label == valid_label[valid_index]:
            accuracy += 1
    return accuracy / valid_data.shape[0]


if __name__ == "__main__":
    hnode_num = 50
    text, label, id_temp = word_split('train.csv', 0)

    # pca进行降维
    # data_tfidf = tf_idf(text)
    # train_tfidf, valid_tfidf, train_label, valid_label = split_data(data_tfidf, label)
    # train_reduced = pca(train_tfidf, hnode_num)
    # valid_reduced = pca(valid_tfidf, hnode_num)

    # doc2vec初次降维
    train_text, valid_text, train_label, valid_label = split_data(text, label)
    train_reduced = build_doc2vec(train_text, hnode_num, "my_train.d2v")
    valid_reduced = build_doc2vec(valid_text, hnode_num, "my_valid.d2v")

    # doc2vec使用训练好的模型
    # temp1, temp2, train_label, valid_label = split_data(text, label)
    # train_model = doc2vec.Doc2Vec.load('train.d2v')
    # valid_model = doc2vec.Doc2Vec.load('valid.d2v')
    # train_reduced = train_model.dv.vectors
    # valid_reduced = valid_model.dv.vectors

    acc = knn(3, 1, train_reduced, train_label, valid_reduced, valid_label)
    print("准确率为： ", acc)
